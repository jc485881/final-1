<?php
//define constants for connection info
define("MYSQLUSER","team17nov18");
define("MYSQLPASS","Team17");
define("HOSTNAME","localhost");
define("MYSQLDB","team17nov18_");

//make connection to database
function db_connect()
{
	$conn = @new mysqli(HOSTNAME, MYSQLUSER, MYSQLPASS, MYSQLDB);
	if($conn -> connect_error) {
		die('Connect Error: ' . $conn -> connect_error);
	}
	return $conn;
} 
?>


